package com.fsc.rating.entities;
public class WordLength {
 
    public String longestWord(String inputStr) {
        if (inputStr != null && !inputStr.isEmpty()) {
            String[] splitArray = inputStr.trim().split(" ");
            String longestWord = splitArray[0];
 
            for (String str : splitArray) {
                if (str.length() > longestWord.length() && str.length() > 0) {
                    longestWord = str;
                }
            }
 
            if (longestWord.length() > 0) {
                return longestWord + "," + longestWord.length();
            } else {
                return "Enter a valid input";
            }
        } else {
            return "Enter a valid input";
        }
 
    }
 
    public String shortestWord(String inputStr) {
        if (inputStr != null && !inputStr.isEmpty()) {
            String[] splitArray = inputStr.trim().split(" ");
            String shortestWord = splitArray[0];
            for (String str : splitArray) {
                if (str.length() < shortestWord.length() && str.length() > 0) {
                    shortestWord = str;
                }
            }
            return shortestWord + "," + shortestWord.length();
        } else {
            return "Enter a valid input";
        }
 
    }
 
    public static void main(String[] args) {
        WordLength wL = new WordLength();
        System.out.println(wL.longestWord("The Tyrannosaurus flew over the moon"));
        System.out.println(wL.shortestWord(" The Tyrannosaurus flew over the moon"));
    }
}
