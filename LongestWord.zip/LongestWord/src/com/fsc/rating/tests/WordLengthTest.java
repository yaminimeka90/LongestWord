package com.fsc.rating.tests;
import junit.framework.TestCase;

import org.junit.Test;

import com.fsc.rating.entities.WordLength;

public class WordLengthTest extends TestCase {

	private WordLength wordLength;

	// assigning the values
	protected void setUp() {
		wordLength = new WordLength();
	}

	@Test
	public void testLongestWord_Valid() {
		String inputString = "The Tyrannosaurus flew over the moon";
		String longestStringAndLength = wordLength.longestWord(inputString);
		String[] splitLongestString = longestStringAndLength.trim().split(",");
		String longestString = splitLongestString[0];
		String longestStringLength = splitLongestString[1];
		assertNotNull(longestString);
		assertNotSame("Enter a valid input", longestString);
		assertEquals("Tyrannosaurus", longestString);
		assertEquals("13", longestStringLength);
	}

	@Test
	public void testLongestWord_Invalid() {
		String inputString = "";
		String longestString = wordLength.longestWord(inputString);
		assertNotNull(longestString);
		assertNotSame("Tyrannosaurus", longestString);
		assertEquals("Enter a valid input", longestString);

	}

	@Test
	public void testShortestWord_Valid() {
		String inputString = "The Tyrannosaurus flew over the moon";
		String shortestStringAndLength = wordLength.shortestWord(inputString);
		String[] splitShortestString = shortestStringAndLength.trim().split(",");
		String shortestString = splitShortestString[0];
		String shortestStringLength = splitShortestString[1];

		assertNotNull(shortestString);
		assertEquals("The", shortestString);
		assertEquals("3", shortestStringLength);
		assertNotSame("Enter a valid input", shortestString);
	}

	@Test
	public void testShortestWord_InValid() {
		String inputString = "";
		String shortestString = wordLength.shortestWord(inputString);
		assertNotNull(shortestString);
		assertNotSame("The", shortestString);
		assertEquals("Enter a valid input", shortestString);

	}

}
